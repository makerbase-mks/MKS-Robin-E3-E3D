"MKS-Robin-E3-E3D-master\firmware\marlin2.0 for CR-10\Marlin\src\pins\stm32\pins_MKS_ROBIN_E3.h" 

#define FLASH_EEPROM_EMULATION
#define EEPROM_PAGE_SIZE     (0x800U) // 2KB
#define EEPROM_START_ADDRESS (0x8000000UL + (STM32_FLASH_SIZE) * 1024UL - (EEPROM_PAGE_SIZE) * 2UL)
#undef E2END
#define E2END                (EEPROM_PAGE_SIZE - 1) // 2KB

"MKS-Robin-E3-E3D-master\firmware\marlin2.0 for CR-10\buildroot\share\PlatformIO\ldscripts\mks_robin_e3.ld" 

MEMORY
{
  ram (rwx) : ORIGIN = 0x20000000, LENGTH = 48K - 40
  rom (rx)  : ORIGIN = 0x08005000, LENGTH = 256K - 20K - 4K
}
